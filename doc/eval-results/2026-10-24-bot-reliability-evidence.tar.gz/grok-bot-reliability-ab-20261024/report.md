# Harness quality comparison

Verdict: **inconclusive**; promotion eligible: **false**.
Evaluation: live. Distinct tasks: 32; trials per variant: 3.

| Category | Baseline pass | Candidate pass | All-trials reliability delta interval |
|---|---:|---:|---|
| routing | 86.7% | 100.0% | -61.0% … 75.8% |
| execution | 94.9% | 97.4% | -39.5% … 39.5% |
| recovery | 100.0% | 100.0% | -68.0% … 68.0% |
| permissions | 83.3% | 100.0% | -75.9% … 95.0% |
| verification | 100.0% | 100.0% | -68.0% … 68.0% |
| compression | 58.3% | 91.7% | -59.2% … 91.2% |

## Gate reasons

- overall non-inferiority not established
- category non-inferiority not established: routing
- category non-inferiority not established: execution
- category non-inferiority not established: recovery
- category non-inferiority not established: permissions
- category non-inferiority not established: verification
- category non-inferiority not established: compression
- missing tokens telemetry

Repeated trials measure stability; they do not multiply the number of independent tasks. Intervals are approximate and apply only to this task distribution.
Simulation verifies the evaluator and harness wiring only. It never establishes model quality or authorizes promotion.
