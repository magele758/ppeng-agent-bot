# Harness quality comparison

Verdict: **baseline_samples**; promotion eligible: **false**.
Evaluation: live. Distinct tasks: 3; trials per variant: 3.

| Category | Baseline pass | Candidate pass | All-trials reliability delta interval |
|---|---:|---:|---|

## Gate reasons

- Baseline samples cannot authorize promotion

Repeated trials measure stability; they do not multiply the number of independent tasks. Intervals are approximate and apply only to this task distribution.
Simulation verifies the evaluator and harness wiring only. It never establishes model quality or authorizes promotion.

Baseline: 8/9 passed; infrastructure failures: 0; trials missing usage: 0.

- compact-tail-failure: PASS; 
- compact-revision: PASS; 
- investigate-fix-en: PASS; 
- compact-tail-failure: PASS; 
- investigate-fix-en: PASS; 
- compact-revision: PASS; 
- investigate-fix-en: PASS; 
- compact-tail-failure: FAIL; exact final answer; actual tool side effects
- compact-revision: PASS; 
