# Harness quality comparison

Verdict: **regressed**; promotion eligible: **false**.
Evaluation: live. Distinct tasks: 32; trials per variant: 3.

| Category | Baseline pass | Candidate pass | All-trials reliability delta interval |
|---|---:|---:|---|
| routing | 100.0% | 93.3% | -75.8% … 61.0% |
| execution | 92.3% | 92.3% | -39.5% … 39.5% |
| recovery | 100.0% | 100.0% | -68.0% … 68.0% |
| permissions | 83.3% | 100.0% | -75.9% … 95.0% |
| verification | 100.0% | 100.0% | -68.0% … 68.0% |
| compression | 75.0% | 83.3% | -79.1% … 79.1% |

## Gate reasons

- category regression: routing
- overall non-inferiority not established
- category non-inferiority not established: routing
- category non-inferiority not established: execution
- category non-inferiority not established: recovery
- category non-inferiority not established: permissions
- category non-inferiority not established: verification
- category non-inferiority not established: compression
- missing tokens telemetry

Repeated trials measure stability; they do not multiply the number of independent tasks. Intervals are approximate and apply only to this task distribution.
Simulation verifies the evaluator and harness wiring only. It never establishes model quality or authorizes promotion.
