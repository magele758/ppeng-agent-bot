# Harness quality comparison

Verdict: **baseline_samples**; promotion eligible: **false**.
Evaluation: live. Distinct tasks: 16; trials per variant: 1.

| Category | Baseline pass | Candidate pass | All-trials reliability delta interval |
|---|---:|---:|---|

## Gate reasons

- Baseline samples cannot authorize promotion

Repeated trials measure stability; they do not multiply the number of independent tasks. Intervals are approximate and apply only to this task distribution.
Simulation verifies the evaluator and harness wiring only. It never establishes model quality or authorizes promotion.
