# Harness quality comparison

Verdict: **baseline_samples**; promotion eligible: **false**.
Evaluation: live. Distinct tasks: 16; trials per variant: 1.

| Category | Baseline pass | Candidate pass | All-trials reliability delta interval |
|---|---:|---:|---|

## Gate reasons

- Baseline samples cannot authorize promotion

Repeated trials measure stability; they do not multiply the number of independent tasks. Intervals are approximate and apply only to this task distribution.
Simulation verifies the evaluator and harness wiring only. It never establishes model quality or authorizes promotion.

Baseline: 15/16 passed; infrastructure failures: 0; trials missing usage: 15.

- polite-fix-zh: PASS; 
- investigate-fix-en: FAIL; actual tool side effects
- pipeline-noun: PASS; 
- sum-invoices: PASS; 
- filter-orders: PASS; 
- dedupe-contacts: PASS; 
- join-records: PASS; 
- report-json: PASS; 
- transient-read: PASS; 
- missing-then-find: PASS; 
- readonly-no-write: PASS; 
- no-outbound: PASS; 
- failed-write-not-done: PASS; 
- claim-is-not-proof: PASS; 
- compact-tail-failure: PASS; 
- compact-artifact: PASS; 
